<div class="page-content-wrap modulo-proveedores">
    <div class="row">
        <div class="col-md-12">
        	<hr>
			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="row">
						<div class="col-md-3">
							<p class="text-center" id="cat">Categorías y lugares de elaboración</p>
						</div>
						<div class="col-md-3">
							<p class="text-center" id="productos">Productos</p>
						</div>
						<div class="col-md-3">
							<p class="text-center" id="cajas">Cajas</p>
						</div>
						<div class="col-md-3">
							<p class="text-center" id="users">Usuarios</p>
						</div>
					</div>
				</div>
				<div class="panel-body">Panel Content</div>
				<div class="panel-footer">
					<div class="row">
						<div class="col-md-10 col-md-offset-1">
							<button type="button" class="btn btn-warning pull-left">Atras</button>
							<button type="button" class="btn btn-warning pull-right">Siguiente</button>
						</div>						
					</div>
				</div>
			</div>        	
        </div>
    </div>
</div>