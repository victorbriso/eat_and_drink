<nav class="fh5co-nav" role="navigation">
	<div class="top">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 text-right">
					<p class="num">+56 9 7605 4659</p>
					<ul class="fh5co-social">
						<li><a href="#"><i class="icon-facebook"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="top-menu">
		<div class="container">
			<div class="row">
				<div class="col-xs-1">
					<div id="fh5co-logo"><a href="index.html">CEOrestobar<span>.</span></a></div>
				</div>
				<div class="col-xs-11 text-right menu-1">
					<ul>
						<li class="active"><a href="index.html">Home</a></li>
						<li><a href="courses.html">Caracteristicas</a></li>
						<li><a href="pricing.html">Precios</a></li>
						<li><a href="contact.html">Contacto</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</div>
</nav>