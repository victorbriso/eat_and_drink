<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
	<div class="overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center">
				<div class="display-t">
					<div class="display-tc animate-box" data-animate-effect="fadeIn">
						<h1>La carta virtual la controlas tu, actualizandola siempre que lo necesites y a un solo click</h1>
						<h2>Sin límite de productos ni categorías</h2>
						<p><a class="btn btn-primary btn-lg btn-learn" href="#">Ver caracteristicas</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>