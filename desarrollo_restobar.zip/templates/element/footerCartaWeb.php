<footer class="page-footer font-small fixed-bottom" style="z-index: 998;">
	<div class="row">
		<div class="col-12 col-md-12 float-right">
			<div class="col-4 col-md-4 float-right">				
				<a href="https://api.whatsapp.com/send?phone=<?=$dataLocal[0]['fono_comercial']?>&text=hola" target="_blank" class="float-right"><?= $this->Html->image('icowsp.png'); ?></a>
			</div>			
		</div>
	</div>
</footer>