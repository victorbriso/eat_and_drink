<footer class="page-footer font-small fixed-bottom" style="z-index: 998;">
	<hr>
	<div class="row">
		<div class="col-6">
			<button class="btn btn-warning btn-block llamaGarzon">Garzón</button>
		</div>
		<div class="col-6">
			<button class="btn btn-danger btn-block pideCuenta">cuenta</button>
		</div>
	</div>
</footer>